A note regarding the examples in this folder:

These examples need the StandardFirmata example sketch from the Arduino examples uploaded to your Arduino.

In addition, you will need to install the Arduino library for Processing before using.